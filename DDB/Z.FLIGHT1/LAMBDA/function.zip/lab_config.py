boto_args = {'service_name': 'dynamodb'}
#boto_args['endpoint_url'] = 'http://localhost:8000'
